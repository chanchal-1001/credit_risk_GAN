# __init__.py

print("This statement will execute when Utils is imported.")

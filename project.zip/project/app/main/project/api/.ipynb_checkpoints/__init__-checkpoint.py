# __init__.py

print("This statement will execute when api is imported.")

PACKAGE_CONSTANT = 42

# __init__.py

print("This statement will execute when the services package is imported.")

